<?php

namespace VitalHCF\crate;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\math\Vector3;
use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\level\Level;

class Crate {
	
	/** @var array */
	public $items = [], $position = [];
	
	/** @var String */
	public $name = "", $keyName = "";
	
	/**
	 * @param String $name
	 * @param Array $items
	 * @param String $keyName
	 * @param Array $position
	 */
	public function __construct(String $name, Array $items = [], String $keyName = "", Array $position = []){
		$this->name = $name;
		$this->items = $items;
		$this->keyName = $keyName;
		$this->position = $position;
	}
	
	/**
	 * @return String[]
	 */
	public function getName() : String {
		return $this->name;
	}
	
	/**
	 * @return Array[]
	 */
	public function getItems() : Array {
		return $this->items;
	}

	/**
	 * @return String[]
	 */
	public function getKeyName() : String {
		return $this->keyName;
	}
	
	/**
	 * @return Array[]
	 */
	public function getPosition() : Array {
		return $this->position;
	}
	
	/**
	 * @param Vector3 $position
	 * @return bool
	 */
	public function isInPosition(Vector3 $position) : bool {
		if(isset($this->position[0][$position->getFloorX()], $this->position[1][$position->getFloorY()], $this->position[2][$position->getFloorZ()])){
			return true;
		}else{
			return false;
		}
		return false;
	}
}

?>