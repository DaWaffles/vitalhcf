<?php

namespace VitalHCF\crate;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\item\Items;

use pocketmine\utils\{Config, TextFormat as TE};

use RuntimeException;

class CrateBackup {

    /**
     * @return void
     */
    public static function init() : void {
        $items = [];

        $data = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."crates.yml", Config::YAML);
        foreach($data->getAll() as $crateName => $crate){
            $file = $data->getAll();
            $crateData = $file[$crateName];
            if(isset($crateData["items"])){
                foreach($crateData["items"] as $slot => $item){
                    $items[$slot] = Items::itemDeserialize($item);
                }
            }
            Loader::$crates[$crateName] = new Crate($crateName, $items, $crateData["keyName"], $crateData["position"]);
        }
    }

    /**
     * @return void
     */
    public static function save() : void {
        $crateData = [];
        $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."crates.yml", Config::YAML);
        foreach(CrateManager::getCrates() as $crate){
            $crateData["keyName"] = $crate->getKeyName();
            $crateData["position"] = $crate->getPosition();
            foreach($crate->getItems() as $slot => $item){
                $crateData["items"][$slot] = Items::itemSerialize($item);
            }
            $file->set($crate->getName(), $crateData);
            $file->save();
        }
    }

    /**
     * @param String $crateName
     * @return void
     */
    public static function delete(String $crateName) : void {
        if(!CrateManager::isCrate($crateName)){
            throw new RuntimeException("{$crateName} does not exist!");
        }
        $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."crates.yml", Config::YAML);
        $file->remove($crateName);
        $file->save();
        unset(Loader::$crates[$crateName]);

    }
}

?>