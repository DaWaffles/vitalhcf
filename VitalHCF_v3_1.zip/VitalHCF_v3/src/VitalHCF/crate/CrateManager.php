<?php

namespace VitalHCF\crate;

use VitalHCF\Loader;
use VitalHCF\player\Player;

class CrateManager {
	
	/**
	 * @param String $crateName
	 * @return bool
	 */
	public static function isCrate(String $crateName) : bool {
		if(isset(Loader::$crates[$crateName])){
			return true;
		}else{
			return false;
		}
		return false;
	}
	
	/**
	 * @param String $crateName
	 * @return Crate[]
	 */
	public static function getCrate(String $crateName) : Crate {
		$crate = null;
		if(self::isCrate($crateName)){
			$crate = clone Loader::$crates[$crateName];
		}
		return $crate;
	}
	
	/**
	 * @return Array[]
	 */
	public static function getCrates() : Array {
		return Loader::$crates;
	}
}

?>